<?php
include_once("conexion.php");
header("Access-Control-Allow-Origin: http://localhost:19006");
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
class crudSBID
{
    public static function buscarporid($id)
    {
        $bd = new Conexion();
        $bd = $bd->conectar();

        $array = array();
        $resultado = $bd->query("SELECT * FROM estudiante WHERE cedula = '$id'");

        while ($row = $resultado->fetch()) {
            $e = array();
            $e["cedula"] = $row[0];
            $e["nombre"] = $row[1];
            $e["apellido"] = $row[2];
            $e["direccion"] = $row[3];
            $e["telefono"] = $row[4];
            array_push($array, $e);
        }
        echo json_encode($array);
    }
}

