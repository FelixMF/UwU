<?php
    include_once("conexion.php");
    $objeto = new conexion();
    $conectar=$objeto->conectar();
?>